'use strict'

class path{
     authUrl(url,method,urlFound) {
         var autorizacao=40 //Não aceitável
        if(url==urlFound)
        {
        autorizacao=100 //Prosseguir

        }

        return autorizacao
    }
}
module.exports=path
